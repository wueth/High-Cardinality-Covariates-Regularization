#=====================================================
# Pre-process data
#=====================================================
# Date: August 08, 2023
# Authors: Mario W�thrich and Ronald Richman
#=====================================================

load(file="./rdata/df.rda")

PreProcess.Continuous <- function(var1, dat2){
   names(dat2)[names(dat2) == var1]  <- "V1"
   dat2$X <- as.numeric(dat2$V1)
   dat2$X <- (dat2$X-mean(dat2$X))/sd(dat2$X)
   names(dat2)[names(dat2) == "V1"]  <- var1
   names(dat2)[names(dat2) == "X"]  <- paste(var1,"X", sep="")
   dat2
   }

Features.PreProcess <- function(dat2){
   dat2 <- PreProcess.Continuous("VehUse", dat2)
   dat2 <- PreProcess.Continuous("Town", dat2)
   dat2 <- PreProcess.Continuous("DrivAge", dat2)
   dat2 <- PreProcess.Continuous("VehWeight", dat2)
   dat2 <- PreProcess.Continuous("VehPower", dat2)
   dat2 <- PreProcess.Continuous("VehAge", dat2)
   dat2$VehBrandX  <- as.integer(dat2$VehBrand)-1
   dat2$VehModelX  <- as.integer(dat2$VehModel)-1
   dat2$VehDetailX <- as.integer(dat2$VehDetail)-1
   dat2
    }


#=====================================================

dat <- Features.PreProcess(df)
