#=====================================================
# Definition of networks
#=====================================================
# Date: August 8, 2023
# Authors: Mario W�thrich and Ronald Richman
#=====================================================

library(keras)
library(tensorflow)

#=====================================================
# loss functions and plots
#=====================================================

plot.loss <- function(pos0, loss, title0, ylim0, plot.yes=0, filey1, col0){
  if (plot.yes==1){pdf(filey1)}      
    plot(loss$val_loss, col=col0[2], ylim=ylim0, main=list(title0, cex=1.5),xlab="training epochs", ylab="(modified) deviance loss", cex=1.5, cex.lab=1.5)
    lines(loss$loss,col=col0[1])
    abline(v=which.min(fit[[2]]$val_loss), col=col0[3])
    legend(x=pos0, cex=1.5, col=col0, lty=c(1,-1,1), lwd=c(1,-1,1), pch=c(-1,1,-1), legend=c("training loss", "validation loss", "minimal validation loss"))
if (plot.yes==1){dev.off()}          
   }

epsilon0 <- 0.0000000001
Poisson.Deviance <- function(obs, est){200*mean(est-obs-obs*log(est/(obs+epsilon0)))}
poisson_loss     <- function(y_true, y_pred){2*k_mean(y_pred[,1]-y_true[,1]-y_true[,1]*k_log(y_pred[,1]/(y_true[,1]+epsilon0)))}
KL.divergence    <- function(true, est){100*mean(est-true-true*log(est/true))}


#=====================================================
# neural network for MAP regularization
#=====================================================

network.output3 <- function(seed, q0, CatN, d, acti='exponential', y0, train){
    k_clear_session()
    set.seed(seed)
    set_random_seed(seed)
    #use_session_with_seed(seed)
    Design   <- layer_input(shape = c(q0[1]), dtype = 'float32', name = 'Design')
    Cat1     <- layer_input(shape = c(1), dtype = 'int32', name = 'Cat1')
    Cat2     <- layer_input(shape = c(1), dtype = 'int32', name = 'Cat2')
    Cat3     <- layer_input(shape = c(1), dtype = 'int32', name = 'Cat3')
    #
    Cat1Emb = Cat1 %>%
      layer_embedding(input_dim = CatN[1], output_dim = d, input_length = 1, name = 'Cat1Emb',
                      trainable = train[1]) %>% layer_flatten(name = 'Cat1_flat')
    Cat2Emb = Cat2 %>%
      layer_embedding(input_dim = CatN[2], output_dim = d, input_length = 1, name = 'Cat2Emb',
                      trainable = train[2]) %>% layer_flatten(name = 'Cat2_flat')
    Cat3Emb = Cat3 %>%
      layer_embedding(input_dim = CatN[3], output_dim = d, input_length = 1, name = 'Cat3Emb',
                      trainable = train[3]) %>% layer_flatten(name = 'Cat3_flat')
    #
    Network = list(Design, Cat1Emb, Cat2Emb, Cat3Emb) %>% layer_concatenate(name='concate') %>%
          layer_dense(units=q0[2], activation='tanh', name='FNLayer1') %>%
          layer_dense(units=q0[3], activation='tanh', name='FNLayer2') %>%
          layer_dense(units=q0[4], activation='tanh', name='FNLayer3') %>%
          layer_dense(units=1, activation=acti, name='Network',
                    weights=list(array(0, dim=c(q0[4],1)), array(y0, dim=c(1))))
    #
    Output = list(Network, Cat1Emb, Cat2Emb, Cat3Emb) %>% layer_concatenate()
    keras_model(inputs = c(Design, Cat1, Cat2, Cat3), outputs = c(Output))
    }

#=====================================================
# neural network for MAP regularization:
# architecture of Avanzi et al. (2023), arXiv2301.00021
#=====================================================

network.output.A3 <- function(seed, q0, CatN, d, acti='exponential', y0, train){
    k_clear_session()
    set.seed(seed)
    set_random_seed(seed)
    d <- 1
    #use_session_with_seed(seed)
    Design   <- layer_input(shape = c(q0[1]), dtype = 'float32', name = 'Design')
    Cat1     <- layer_input(shape = c(1), dtype = 'int32', name = 'Cat1')
    Cat2     <- layer_input(shape = c(1), dtype = 'int32', name = 'Cat2')
    Cat3     <- layer_input(shape = c(1), dtype = 'int32', name = 'Cat3')
    #
    Cat1Emb = Cat1 %>%
      layer_embedding(input_dim = CatN[1], output_dim = d, input_length = 1, name = 'Cat1Emb',
                      trainable = train[1]) %>% layer_flatten(name = 'Cat1_flat')
    Cat2Emb = Cat2 %>%
      layer_embedding(input_dim = CatN[2], output_dim = d, input_length = 1, name = 'Cat2Emb',
                      trainable = train[2]) %>% layer_flatten(name = 'Cat2_flat')
    Cat3Emb = Cat3 %>%
      layer_embedding(input_dim = CatN[3], output_dim = d, input_length = 1, name = 'Cat3Emb',
                      trainable = train[3]) %>% layer_flatten(name = 'Cat3_flat')
    #
    Network = Design %>%
          layer_dense(units=q0[2], activation='tanh', name='FNLayer1') %>%
          layer_dense(units=q0[3], activation='tanh', name='FNLayer2') %>%
          layer_dense(units=q0[4], activation='tanh', name='FNLayer3')
    #
    Output0 = list(Network, Cat1Emb, Cat2Emb, Cat3Emb) %>% layer_concatenate(name='concate') %>%
          layer_dense(units=1, activation=acti, name='Network',
                    weights=list(array(0, dim=c(q0[4]+3*d,1)), array(y0, dim=c(1))))
    #
    Output = list(Output0, Cat1Emb, Cat2Emb, Cat3Emb) %>% layer_concatenate()
    #
    keras_model(inputs = c(Design, Cat1, Cat2, Cat3), outputs = c(Output))
    }



#=====================================================
# variational Bayesian inference network with noise
#=====================================================

network.VI3 <- function(seed, q0, CatN, d, acti='sigmoid', y0, v0, train){
    k_clear_session()
    set.seed(seed)
    set_random_seed(seed)
    #use_session_with_seed(seed)
    Design   <- layer_input(shape = c(q0[1]), dtype = 'float32', name = 'Design')
    Cat1     <- layer_input(shape = c(1), dtype = 'int32', name = 'Cat1')
    Noise2   <- layer_input(shape = c(d), dtype = 'float32', name = 'Noise2')
    Cat2     <- layer_input(shape = c(1), dtype = 'int32', name = 'Cat2')
    Noise3   <- layer_input(shape = c(d), dtype = 'float32', name = 'Noise3')
    Cat3     <- layer_input(shape = c(1), dtype = 'int32', name = 'Cat3')
    #
    Cat1Emb = Cat1 %>%
      layer_embedding(input_dim = CatN[1], output_dim = d, input_length = 1, name = 'Cat1Emb',
                      trainable = train[1]) %>% layer_flatten(name = 'Cat1_flat')
    #
    Mu2 = Cat2 %>%
      layer_embedding(input_dim = CatN[2], output_dim = d, input_length = 1, name = 'Cat2Emb',
                      trainable = train[2]) %>% layer_flatten(name = 'Cat2_flat')
    Sigma2 = Cat2 %>%
      layer_embedding(input_dim = CatN[2], output_dim = d, input_length = 1, name = 'Sig2Emb',
                      weights=list(array(v0, dim=c(CatN[2],d))),
                      trainable = train[2]) %>%
      layer_flatten(name='Sig2_flat') %>% layer_lambda(function(x) k_abs(x))
    uu2 = list(Noise2, Sigma2) %>% layer_multiply()
    RandomEffects2 = list(Mu2, uu2) %>% layer_add()
    #
    Mu3 = Cat3 %>%
      layer_embedding(input_dim = CatN[3], output_dim = d, input_length = 1, name = 'Cat3Emb',
                      trainable = train[3]) %>% layer_flatten(name = 'Cat3_flat')
    Sigma3 = Cat3 %>%
      layer_embedding(input_dim = CatN[3], output_dim = d, input_length = 1, name = 'Sig3Emb',
                      weights=list(array(v0, dim=c(CatN[3],d))),
                      trainable = train[3]) %>%
      layer_flatten(name='Sig3_flat') %>% layer_lambda(function(x) k_abs(x))
    uu3 = list(Noise3, Sigma3) %>% layer_multiply()
    RandomEffects3 = list(Mu3, uu3) %>% layer_add()
    #
    Network = list(Design, Cat1Emb, RandomEffects2, RandomEffects3) %>% layer_concatenate(name='concate') %>%
          layer_dense(units=q0[2], activation='tanh', name='FNLayer1') %>%
          layer_dense(units=q0[3], activation='tanh', name='FNLayer2') %>%
          layer_dense(units=q0[4], activation='tanh', name='FNLayer3') %>%
          layer_dense(units=1, activation=acti, name='Network',
                    weights=list(array(0, dim=c(q0[4],1)), array(y0, dim=c(1))))
    #
    Output = list(Network, Mu2, Sigma2, Mu3, Sigma3) %>% layer_concatenate()
    keras_model(inputs = c(Design, Cat1, Cat2, Cat3, Noise2, Noise3), outputs = c(Output))
    }


#=====================================================
# variational Bayesian inference network with noise
# architecture of Avanzi et al. (2023), arXiv2301.00021
#=====================================================

network.VI.A3 <- function(seed, q0, CatN, d, acti='sigmoid', y0, v0, train){
    k_clear_session()
    set.seed(seed)
    set_random_seed(seed)
    d <- 1
    #use_session_with_seed(seed)
    Design   <- layer_input(shape = c(q0[1]), dtype = 'float32', name = 'Design')
    Cat1     <- layer_input(shape = c(1), dtype = 'int32', name = 'Cat1')
    Noise2   <- layer_input(shape = c(d), dtype = 'float32', name = 'Noise2')
    Cat2     <- layer_input(shape = c(1), dtype = 'int32', name = 'Cat2')
    Noise3   <- layer_input(shape = c(d), dtype = 'float32', name = 'Noise3')
    Cat3     <- layer_input(shape = c(1), dtype = 'int32', name = 'Cat3')
    #
    Cat1Emb = Cat1 %>%
      layer_embedding(input_dim = CatN[1], output_dim = d, input_length = 1, name = 'Cat1Emb',
                      trainable = train[1]) %>% layer_flatten(name = 'Cat1_flat')
    #
    Mu2 = Cat2 %>%
      layer_embedding(input_dim = CatN[2], output_dim = d, input_length = 1, name = 'Cat2Emb',
                      trainable = train[2]) %>% layer_flatten(name = 'Cat2_flat')
    Sigma2 = Cat2 %>%
      layer_embedding(input_dim = CatN[2], output_dim = d, input_length = 1, name = 'Sig2Emb',
                      weights=list(array(v0, dim=c(CatN[2],d))),
                      trainable = train[2]) %>%
      layer_flatten(name='Sig2_flat') %>% layer_lambda(function(x) k_abs(x))
    uu2 = list(Noise2, Sigma2) %>% layer_multiply()
    RandomEffects2 = list(Mu2, uu2) %>% layer_add()
    #
    Mu3 = Cat3 %>%
      layer_embedding(input_dim = CatN[3], output_dim = d, input_length = 1, name = 'Cat3Emb',
                      trainable = train[3]) %>% layer_flatten(name = 'Cat3_flat')
    Sigma3 = Cat3 %>%
      layer_embedding(input_dim = CatN[3], output_dim = d, input_length = 1, name = 'Sig3Emb',
                      weights=list(array(v0, dim=c(CatN[3],d))),
                      trainable = train[3]) %>%
      layer_flatten(name='Sig3_flat') %>% layer_lambda(function(x) k_abs(x))
    uu3 = list(Noise3, Sigma3) %>% layer_multiply()
    RandomEffects3 = list(Mu3, uu3) %>% layer_add()
    #
    Network = Design %>%
          layer_dense(units=q0[2], activation='tanh', name='FNLayer1') %>%
          layer_dense(units=q0[3], activation='tanh', name='FNLayer2') %>%
          layer_dense(units=q0[4], activation='tanh', name='FNLayer3')
    #
    Output0 = list(Network, Cat1Emb, RandomEffects2, RandomEffects3) %>% layer_concatenate(name='concate') %>%
          layer_dense(units=1, activation=acti, name='Network',
                    weights=list(array(0, dim=c(q0[4]+3*d,1)), array(y0, dim=c(1))))
    #
    Output = list(Output0, Mu2, Sigma2, Mu3, Sigma3) %>% layer_concatenate()
    keras_model(inputs = c(Design, Cat1, Cat2, Cat3, Noise2, Noise3), outputs = c(Output))
    }


#=====================================================
# hierarchical embeddings for MAP regularization
#=====================================================

network.hierarchical3 <- function(seed, q0, CatN, d, acti='exponential', y0, train){
    k_clear_session()
    set.seed(seed)
    set_random_seed(seed)
    #use_session_with_seed(seed)
    Design   <- layer_input(shape = c(q0[1]), dtype = 'float32', name = 'Design')
    Cat1     <- layer_input(shape = c(1), dtype = 'int32', name = 'Cat1')
    Cat2     <- layer_input(shape = c(1), dtype = 'int32', name = 'Cat2')
    Cat3     <- layer_input(shape = c(1), dtype = 'int32', name = 'Cat3')
    #
    Cat1Emb = Cat1 %>%
      layer_embedding(input_dim = CatN[1], output_dim = d, input_length = 1, name = 'Cat1Emb',
                      trainable = train[1]) %>% layer_flatten(name = 'Cat1_flat')
    Cat2Emb = Cat2 %>%
      layer_embedding(input_dim = CatN[2], output_dim = d, input_length = 1, name = 'Cat2Emb',
                      trainable = train[2]) %>% layer_flatten(name = 'Cat2_flat')
    Cat3Emb = Cat3 %>%
      layer_embedding(input_dim = CatN[3], output_dim = d, input_length = 1, name = 'Cat3Emb',
                      trainable = train[3]) %>% layer_flatten(name = 'Cat3_flat')
    #
    CatEmb = list(Cat1Emb, Cat2Emb, Cat3Emb) %>% layer_add()
    #
    Network = list(Design, CatEmb) %>% layer_concatenate(name='concate') %>%
          layer_dense(units=q0[2], activation='tanh', name='FNLayer1') %>%
          layer_dense(units=q0[3], activation='tanh', name='FNLayer2') %>%
          layer_dense(units=q0[4], activation='tanh', name='FNLayer3') %>%
          layer_dense(units=1, activation=acti, name='Network',
                    weights=list(array(0, dim=c(q0[4],1)), array(y0, dim=c(1))))
    #
    Output = list(Network, Cat1Emb, Cat2Emb, Cat3Emb) %>% layer_concatenate()
    keras_model(inputs = c(Design, Cat1, Cat2, Cat3), outputs = c(Output))
    }

#=====================================================
# recurrent embeddings for MAP regularization
#=====================================================

network.recurrent3 <- function(seed, q0, CatN, d, acti='exponential', y0, train){
    k_clear_session()
    set.seed(seed)
    set_random_seed(seed)
    #use_session_with_seed(seed)
    Design   <- layer_input(shape = c(q0[1]), dtype = 'float32', name = 'Design')
    Cat1     <- layer_input(shape = c(1), dtype = 'int32', name = 'Cat1')
    Cat2     <- layer_input(shape = c(1), dtype = 'int32', name = 'Cat2')
    Cat3     <- layer_input(shape = c(1), dtype = 'int32', name = 'Cat3')
    #
    Cat1Emb = Cat1 %>%
      layer_embedding(input_dim = CatN[1], output_dim = d, input_length = 1, name = 'Cat1Emb',
                      trainable = train[1])
    Cat1Flat = Cat1Emb %>% layer_flatten(name = 'Cat1_flat')
    #
    Cat2Emb = Cat2 %>%
      layer_embedding(input_dim = CatN[2], output_dim = d, input_length = 1, name = 'Cat2Emb',
                      trainable = train[2])
    Cat2Flat = Cat2Emb %>% layer_flatten(name = 'Cat2_flat')
    #
    Cat3Emb = Cat3 %>%
      layer_embedding(input_dim = CatN[3], output_dim = d, input_length = 1, name = 'Cat3Emb',
                      trainable = train[3]) #%>% layer_flatten(name = 'Cat3_flat')
    Cat3Flat = Cat3Emb %>% layer_flatten(name = 'Cat3_flat')
    #
    InputCat = list(Cat1Emb, Cat2Emb, Cat3Emb) %>% layer_concatenate() %>%
                  layer_reshape(target_shape=c(3,d)) %>%
                  layer_simple_rnn(units=d, use_bias=FALSE, return_sequence=TRUE,
                                   activation="tanh") %>% layer_flatten()
    #
    Network = list(Design, InputCat) %>% layer_concatenate(name='concate') %>%
          layer_dense(units=q0[2], activation='tanh', name='FNLayer1') %>%
          layer_dense(units=q0[3], activation='tanh', name='FNLayer2') %>%
          layer_dense(units=q0[4], activation='tanh', name='FNLayer3') %>%
          layer_dense(units=1, activation=acti, name='Network',
                    weights=list(array(0, dim=c(q0[4],1)), array(y0, dim=c(1))))
    #
    Output = list(Network, Cat1Flat, Cat2Flat, Cat3Flat, InputCat) %>% layer_concatenate()
    keras_model(inputs = c(Design, Cat1, Cat2, Cat3), outputs = c(Output))
    }



#=====================================================
# transformer network MAP regularization
#=====================================================


network.transformer3 <- function(seed, q0, CatN, d, acti='exponential', y0, train){
  k_clear_session()
  set.seed(seed)
  set_random_seed(seed)
  #use_session_with_seed(seed)
  Design   <- layer_input(shape = c(q0[1]), dtype = 'float32', name = 'Design')
  Cat1     <- layer_input(shape = c(1), dtype = 'int32', name = 'Cat1')
  Cat2     <- layer_input(shape = c(1), dtype = 'int32', name = 'Cat2')
  Cat3     <- layer_input(shape = c(1), dtype = 'int32', name = 'Cat3')
  #
  Cat1Emb = Cat1 %>%
    layer_embedding(input_dim = CatN[1], output_dim = d, input_length = 1, name = 'Cat1Emb',
                    trainable = train[1])
  Cat1Flat = Cat1Emb %>% layer_flatten(name = 'Cat1_flat')
  #
  Cat2Emb = Cat2 %>%
    layer_embedding(input_dim = CatN[2], output_dim = d, input_length = 1, name = 'Cat2Emb',
                    trainable = train[2])
  Cat2Flat = Cat2Emb %>% layer_flatten(name = 'Cat2_flat')
  #
  Cat3Emb = Cat3 %>%
    layer_embedding(input_dim = CatN[3], output_dim = d, input_length = 1, name = 'Cat3Emb',
                    trainable = train[3]) #%>% layer_flatten(name = 'Cat3_flat')
  Cat3Flat = Cat3Emb %>% layer_flatten(name = 'Cat3_flat')
  #
  InputCat = list(Cat1Emb, Cat2Emb, Cat3Emb) %>% layer_concatenate() %>%
    layer_reshape(target_shape=c(3,d))

  q = InputCat %>% time_distributed(layer_dense(units = d, activation = "tanh")) %>%
                   time_distributed(layer_layer_normalization())
  v = InputCat %>% time_distributed(layer_dense(units = d, activation = "tanh")) %>%
                   time_distributed(layer_layer_normalization())
  k = InputCat %>% time_distributed(layer_dense(units = d, activation = "tanh")) %>%
                   time_distributed(layer_layer_normalization())

  Attention = layer_attention(list(q,v,k), use_scale = TRUE, trainable = TRUE)

  Skip1 = list(InputCat, Attention) %>% layer_add()

  FFN = Skip1 %>% time_distributed(layer_layer_normalization()) %>%
                  time_distributed(layer_dense(units = q0[5], activation = "tanh")) %>%
                  time_distributed(layer_dense(units = d, activation = "tanh"))

  Skip2 = list(Skip1, FFN) %>% layer_add()%>% layer_flatten()

  Network = list(Design, Skip2) %>% layer_concatenate(name='concate') %>%
    layer_dense(units=q0[2], activation='tanh', name='FNLayer1') %>%
    layer_dense(units=q0[3], activation='tanh', name='FNLayer2') %>%
    layer_dense(units=q0[4], activation='tanh', name='FNLayer3') %>%
    layer_dense(units=1, activation=acti, name='Network',
                weights=list(array(0, dim=c(q0[4],1)), array(y0, dim=c(1))))
  #
  Output = list(Network, Cat1Flat, Cat2Flat, Cat3Flat, Skip2) %>% layer_concatenate()
  keras_model(inputs = c(Design, Cat1, Cat2, Cat3), outputs = c(Output))
}
