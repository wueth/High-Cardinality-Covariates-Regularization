#=====================================================
# Fitting plain-vanilla neural networks (no regularization)
#=====================================================
# Date: August 8, 2023
# Authors: Mario W�thrich and Ronald Richman
#=====================================================

source(file="./Tools/00_a load data.R")
source(file="./Tools/00_b networks.R")

#=====================================================
# Selecting Training-Validation split for network fitting.
# Checking whether training data contains all categorical levels.
#=====================================================

dat$ClaimNb <- as.numeric(dat$ClaimNb)
# training - validation split being 8:2
set.seed(200)
ll <- sample(x=nrow(dat), size=round(nrow(dat)*.8), replace=FALSE)
# training data: considers all levels?? Otherwise change seed.
learn0 <- dat[ll,]
setdiff(unique(dat$VehDetail), unique(learn0$VehDetail))
# validation data
learn1 <- dat[-ll,]
setdiff(unique(dat$VehDetail), unique(learn1$VehDetail))

#=====================================================
# Pre-processing data for neural network fitting
#=====================================================

cont.features <- c("VehUseX", "TownX", "DrivAgeX", "VehWeightX", "VehPowerX", "VehAgeX")

# training data for gradient descent
learn0.design <- as.matrix(learn0[,cont.features])
learn0.cat1 <- as.matrix(learn0[,"VehBrandX"])
learn0.cat2 <- as.matrix(learn0[,"VehModelX"])
learn0.cat3 <- as.matrix(learn0[,"VehDetailX"])
yy0 <- as.matrix(learn0[,c("ClaimNb")])
# validation data for gradient descent
learn1.design <- as.matrix(learn1[,cont.features])
learn1.cat1 <- as.matrix(learn1[,"VehBrandX"])
learn1.cat2 <- as.matrix(learn1[,"VehModelX"])
learn1.cat3 <- as.matrix(learn1[,"VehDetailX"])
yy1 <- as.matrix(learn1[,c("ClaimNb")])
# all learning data
dat.design <- as.matrix(dat[,cont.features])
dat.cat1 <- as.matrix(dat[,"VehBrandX"])
dat.cat2 <- as.matrix(dat[,"VehModelX"])
dat.cat3 <- as.matrix(dat[,"VehDetailX"])
yy <- as.matrix(dat[,c("ClaimNb")])

#=====================================================
# Homogeneous (null) model
#=====================================================

# empirical frequency
(lambda0 <- mean(yy))

# in-sample loss and KL divergence of null model
round(c(Poisson.Deviance(yy, lambda0), KL.divergence(dat$True, lambda0)),4)

# analysis of training and validation split
round(c(Poisson.Deviance(yy, lambda0), Poisson.Deviance(yy0, lambda0), Poisson.Deviance(yy1, lambda0)),4)
round(c(KL.divergence(dat$True, lambda0), KL.divergence(learn0$True, lambda0), KL.divergence(learn1$True, lambda0)),4)


#=====================================================
# neural network fitting
#=====================================================

# number of neurons in the hidden layers
(qq <- c(length(cont.features),20,15,10))
# number of categorical levels
(catN <- c(length(unique(dat$VehBrand)),length(unique(dat$VehModel)),length(unique(dat$VehDetail))))

# which of the three categorical variables are included
train <- rbind(c(FALSE, FALSE, FALSE),
               c(TRUE,  FALSE, FALSE),
               c(FALSE, TRUE,  FALSE),
               c(FALSE, FALSE, TRUE),
               c(TRUE,  TRUE, FALSE),
               c(TRUE, TRUE, TRUE))

J0 <- nrow(train)

#=====================================================
# no regularization: network with embeddings
#=====================================================

T0 <- 10          # average results over T0 network fittings
epochs0  <- 200   # number of training epochs
batch0   <- 2000  # batch size
result   <- array(NA, c(J0, T0))
ensemble <- array(NA, c(J0))

for (j0 in 1:J0){
  for (t0 in 1:T0){
    seed <- 100 + t0
    path1 <- paste("./Networks/network",j0,"_",seed, sep="")
    model <- network.output3(seed=seed, q0=qq, CatN=catN, d=2, acti='exponential',
                                   y0=log(lambda0), train=train[j0,])
    model %>% compile(loss = poisson_loss, optimizer = 'nadam')
    w1 <- get_weights(model)
    if (!(train[j0,1])){w1[[1]] <- array(0,dim=dim(w1[[1]]))}
    if (!(train[j0,2])){w1[[2]] <- array(0,dim=dim(w1[[2]]))}
    if (!(train[j0,3])){w1[[3]] <- array(0,dim=dim(w1[[3]]))}
    set_weights(model, w1)
    CBs <- callback_model_checkpoint(path1, monitor = "val_loss", verbose = 0,  save_best_only = TRUE, save_weights_only = TRUE)
    ### takes long, only load fitted networks
    #fit <- model %>% fit(list(learn0.design, learn0.cat1, learn0.cat2, learn0.cat3),  yy0,
    #                validation_data=list(list(learn1.design, learn1.cat1, learn1.cat2, learn1.cat3),  yy1),
    #                batch_size=batch0, epochs=epochs0, verbose=0, callbacks=CBs)
    #plot.loss("topright", fit[[2]], paste("network ",j0,"/",J0,", iteration ", t0, "/",T0, sep=""), ylim0=range(fit[[2]]), plot.yes=0, "", col0=c("blue","darkgreen", "orange"))
    load_model_weights_hdf5(model, path1)
    pred <- (model %>% predict(list(dat.design, dat.cat1, dat.cat2, dat.cat3), batch_size=10^6))[,1]
    if (t0==1){predE <- pred/T0
        }else{
          predE <- predE + pred/T0
          }
    result[j0, t0] <- KL.divergence(dat$True, pred)
       }
    ensemble[j0] <- KL.divergence(dat$True, predE)
       }

###
cbind(round(rowMeans(result),4), round(ensemble,4))

#=====================================================
# no regularization: architecture of Avanzi et al. (2023), arXiv2301.00021
#=====================================================

T0 <- 10         # average results over T0 network fittings
epochs0 <- 200   # number of training epochs
batch0  <- 2000  # batch size
resultA <- array(NA, c(J0, T0))
ensemble <- array(NA, c(J0))


for (j0 in 1:J0){
  for (t0 in 1:T0){
    seed <- 100 + t0
    path1 <- paste("./NetworksA/networkA",j0,"_",seed, sep="")
    model <- network.output.A3(seed=seed, q0=qq, CatN=catN, d=2, acti='exponential',
                                   y0=log(lambda0), train=train[j0,])
    model %>% compile(loss = poisson_loss, optimizer = 'nadam')
    w1 <- get_weights(model)
    if (!(train[j0,1])){w1[[5]] <- array(0,dim=dim(w1[[5]]))}
    if (!(train[j0,2])){w1[[6]] <- array(0,dim=dim(w1[[6]]))}
    if (!(train[j0,3])){w1[[7]] <- array(0,dim=dim(w1[[7]]))}
    set_weights(model, w1)
    CBs <- callback_model_checkpoint(path1, monitor = "val_loss", verbose = 0,  save_best_only = TRUE, save_weights_only = TRUE)
    ### takes long, only load fitted networks
    #fit <- model %>% fit(list(learn0.design, learn0.cat1, learn0.cat2, learn0.cat3),  yy0,
    #                validation_data=list(list(learn1.design, learn1.cat1, learn1.cat2, learn1.cat3),  yy1),
    #                batch_size=batch0, epochs=epochs0, verbose=0, callbacks=CBs)
    #plot.loss("topright", fit[[2]], paste("network ",j0,"/",J0,", iteration ", t0, "/",T0, sep=""), ylim0=range(fit[[2]]), plot.yes=0, "", col0=c("blue","darkgreen", "orange"))
    load_model_weights_hdf5(model, path1)
    pred <- (model %>% predict(list(dat.design, dat.cat1, dat.cat2, dat.cat3), batch_size=10^6))[,1]
    resultA[j0, t0] <- KL.divergence(dat$True, pred)
    if (t0==1){predE <- pred/T0
        }else{
          predE <- predE + pred/T0
          }
       }
    ensemble[j0] <- KL.divergence(dat$True, predE)
       }

###
cbind(round(rowMeans(resultA),4), round(ensemble,4))

