#=====================================================
# Categorical regularization (non-hierarchical): ad-hoc
#=====================================================
# Date: August 8, 2023
# Authors: Mario W�thrich and Ronald Richman
#=====================================================

library(tidyverse)
library(arrow)

source(file="./Tools/00_a load data.R")
source(file="./Tools/00_b networks.R")

str(dat)

#=====================================================
# Selecting Training-Validation split for network fitting.
# Checking whether training data contains all categorical levels.
#=====================================================

dat$ClaimNb <- as.numeric(dat$ClaimNb)
# training - validation split being 8:2
set.seed(200)
ll <- sample(x=nrow(dat), size=round(nrow(dat)*.8), replace=FALSE)
# training data: considers all levels?? Otherwise change seed.
learn0 <- dat[ll,]
setdiff(unique(dat$VehDetail), unique(learn0$VehDetail))
# validation data
learn1 <- dat[-ll,]
setdiff(unique(dat$VehDetail), unique(learn1$VehDetail))

#=====================================================
# Pre-processing data for neural network fitting
#=====================================================

cont.features <- c("VehUseX", "TownX", "DrivAgeX", "VehWeightX", "VehPowerX", "VehAgeX")

# training data for gradient descent
learn0.design <- as.matrix(learn0[,cont.features])
learn0.cat1 <- as.matrix(learn0[,"VehBrandX"])
learn0.cat2 <- as.matrix(learn0[,"VehModelX"])
learn0.cat3 <- as.matrix(learn0[,"VehDetailX"])
yy0 <- as.matrix(learn0[,c("ClaimNb")])
# validation data for gradient descent
learn1.design <- as.matrix(learn1[,cont.features])
learn1.cat1 <- as.matrix(learn1[,"VehBrandX"])
learn1.cat2 <- as.matrix(learn1[,"VehModelX"])
learn1.cat3 <- as.matrix(learn1[,"VehDetailX"])
yy1 <- as.matrix(learn1[,c("ClaimNb")])
# all learning data
dat.design <- as.matrix(dat[,cont.features])
dat.cat1 <- as.matrix(dat[,"VehBrandX"])
dat.cat2 <- as.matrix(dat[,"VehModelX"])
dat.cat3 <- as.matrix(dat[,"VehDetailX"])
yy <- as.matrix(dat[,c("ClaimNb")])

#=====================================================
# Homogeneous (null) model
#=====================================================

# empirical frequency
(lambda0 <- mean(yy))

# in-sample loss and KL divergence of null model
round(c(Poisson.Deviance(yy, lambda0), KL.divergence(dat$True, lambda0)),4)


#=====================================================
# neural network fitting
#=====================================================

# number of neurons in the hidden layers
(qq <- c(length(cont.features),20,15,10))
# number of categorical levels
(catN <- c(length(unique(dat$VehBrand)),length(unique(dat$VehModel)),length(unique(dat$VehDetail))))

# which of the three categorical variables are included
train <- rbind(c(TRUE,  TRUE, FALSE),
               c(TRUE,  TRUE, TRUE))

J0 <- nrow(train)

# number of observations per level
learn0$n <- 1
Cat3 <- data.frame(learn0 %>% group_by(VehDetailX) %>% summarize(nn = sum(n)))
learn0$W3 <- Cat3[learn0$VehDetailX+1,"nn"]
learn1$W3 <- Cat3[learn1$VehDetailX+1,"nn"]
Cat2 <- data.frame(learn0 %>% group_by(VehModelX) %>% summarize(nn = sum(n)))
learn0$W2 <- Cat2[learn0$VehModelX+1,"nn"]
learn1$W2 <- Cat2[learn1$VehModelX+1,"nn"]
Cat1 <- data.frame(learn0 %>% group_by(VehBrandX) %>% summarize(nn = sum(n)))
learn0$W1 <- Cat1[learn0$VehBrandX+1,"nn"]
learn1$W1 <- Cat1[learn1$VehBrandX+1,"nn"]
# extend responses with aggregate case weights
yy0.weights <- as.matrix(learn0[,c("ClaimNb", "W1", "W2", "W3")])
yy1.weights <- as.matrix(learn1[,c("ClaimNb", "W1", "W2", "W3")])


# Gaussian noise terms
set.seed(500)
learn0.epsilon2 <- as.matrix(cbind(rnorm(nrow(learn0)), rnorm(nrow(learn0))))
learn0.epsilon3 <- as.matrix(cbind(rnorm(nrow(learn0)), rnorm(nrow(learn0))))
learn1.epsilon2 <- as.matrix(cbind(rnorm(nrow(learn1)), rnorm(nrow(learn1))))
learn1.epsilon3 <- as.matrix(cbind(rnorm(nrow(learn1)), rnorm(nrow(learn1))))
dat.epsilon2 <- as.matrix(cbind(rep(0,nrow(dat)), rep(0,nrow(dat))))
dat.epsilon3 <- as.matrix(cbind(rep(0,nrow(dat)), rep(0,nrow(dat))))


#=====================================================
# ad-hoc regularization: network with embeddings
#=====================================================

T0 <- 10         # average results over T0 network fittings
epochs0 <- 200   # number of training epochs
batch0  <- 2000  # batch size

eta2 <- c(0, 10^3, 10^3)
tau1 <- c(10^(-6), 10^(-5))

results2 <- array(NA, c(J0, T0))
v0=0.00001       # initial value for variance parameter
ensemble <- array(NA, c(J0))


for (j0 in 1:J0){
  for (t0 in 1:T0){
    seed <- 100 + t0
    path1 <- paste("./Networks/AdHoc",j0,"_",seed, sep="")
    model <- network.VI3(seed=seed, q0=qq, CatN=catN, d=2, acti='exponential',
                                   y0=log(lambda0), v0, train=train[j0,])
    eta1 <- eta2
    if (!(train[j0,3])){eta1[3] <- 0}
    Q_loss3 <- function(y_true, y_pred){
         k_mean(2*(y_pred[,1] - y_true[,1] - y_true[,1]*k_log(y_pred[,1]/(y_true[,1]+.00000001)))+
            eta1[2]*(y_pred[,2]^2 + y_pred[,3]^2 +
                  tau1[1]/2*((y_pred[,4]^2/tau1[1]-1)^2+(y_pred[,5]^2/tau1[1]-1)^2))/y_true[,3] +
            eta1[3]*(y_pred[,6]^2 + y_pred[,7]^2 +
                  tau1[2]/2*((y_pred[,8]^2/tau1[2]-1)^2+(y_pred[,9]^2/tau1[2]-1)^2))/y_true[,4])}

    model %>% compile(loss = Q_loss3, optimizer = 'nadam')
    w1 <- get_weights(model)
    if (!(train[j0,3])){w1[[4]] <- array(0,dim=dim(w1[[4]]))}
    if (!(train[j0,3])){learn0.epsilon3 <- array(0,dim=dim(learn0.epsilon3))}
    if (!(train[j0,3])){learn1.epsilon3 <- array(0,dim=dim(learn1.epsilon3))}
    set_weights(model, w1)
    CBs <- callback_model_checkpoint(path1, monitor = "val_loss", verbose = 0,  save_best_only = TRUE, save_weights_only = TRUE)
    ### takes long, only load fitted networks
    #fit <- model %>% fit(list(learn0.design, learn0.cat1, learn0.cat2, learn0.cat3, learn0.epsilon2, learn0.epsilon3),  yy0.weights,
    #                validation_data=list(list(learn1.design, learn1.cat1, learn1.cat2, learn1.cat3, learn1.epsilon2, learn1.epsilon3),  yy1.weights),
    #                batch_size=batch0, epochs=epochs0, verbose=0, callbacks=CBs)
    #plot.loss("topright", fit[[2]], paste("network ",j0,"/",J0,", iteration ", t0, "/",T0, sep=""), ylim0=range(fit[[2]]), plot.yes=0, "", col0=c("blue","darkgreen", "orange"))
    load_model_weights_hdf5(model, path1)
    pred <- (model %>% predict(list(dat.design, dat.cat1, dat.cat2, dat.cat3, dat.epsilon2, dat.epsilon3), batch_size=10^6))[,1]
    results2[j0, t0] <- KL.divergence(dat$True, pred)
    if (t0==1){predE <- pred/T0
        }else{
          predE <- predE + pred/T0
          }
       }
    ensemble[j0] <- KL.divergence(dat$True, predE)
    }

###
cbind(round(rowMeans(results2),4), round(ensemble,4))


#=====================================================
# ad-hoc regularization: architecture of Avanzi et al. (2023), arXiv2301.00021
#=====================================================

T0 <- 10         # average results over T0 network fittings
epochs0 <- 200   # number of training epochs
batch0  <- 2000  # batch size
eta2 <- c(0, 10^3, 10^3)
tau1 <- c(10^(-4), 10^(-4))

results2A <- array(NA, c(J0, T0))
v0=0.00001       # initial value for variance parameter
ensemble <- array(NA, c(J0))

for (j0 in 1:J0){
  for (t0 in 1:T0){
    seed <- 100 + t0
    path1 <- paste("./Networks/AdHocA",j0,"_",seed, sep="")
    model <- network.VI.A3(seed=seed, q0=qq, CatN=catN, d=2, acti='exponential',
                                   y0=log(lambda0), v0, train=train[j0,])
    eta1 <- eta2
    if (!(train[j0,3])){eta1[3] <- 0}
    Q_loss3 <- function(y_true, y_pred){
         k_mean(2*(y_pred[,1] - y_true[,1] - y_true[,1]*k_log(y_pred[,1]/(y_true[,1]+.00000001)))+
            eta1[2]*(y_pred[,2]^2 +
                  tau1[1]/2*((y_pred[,3]^2/tau1[1]-1)^2))/y_true[,3] +
            eta1[3]*(y_pred[,4]^2 +
                  tau1[2]/2*((y_pred[,5]^2/tau1[2]-1)^2))/y_true[,4])}

    model %>% compile(loss = Q_loss3, optimizer = 'nadam')
    w1 <- get_weights(model)
    if (!(train[j0,3])){w1[[6]] <- array(0,dim=dim(w1[[6]]))}
    if (!(train[j0,3])){learn0.epsilon3 <- array(0,dim=dim(learn0.epsilon3))}
    if (!(train[j0,3])){learn1.epsilon3 <- array(0,dim=dim(learn1.epsilon3))}
    set_weights(model, w1)
    CBs <- callback_model_checkpoint(path1, monitor = "val_loss", verbose = 0,  save_best_only = TRUE, save_weights_only = TRUE)
    ### takes long, only load fitted networks
    #fit <- model %>% fit(list(learn0.design, learn0.cat1, learn0.cat2, learn0.cat3, learn0.epsilon2[,1], learn0.epsilon3[,1]),  yy0.weights,
    #                validation_data=list(list(learn1.design, learn1.cat1, learn1.cat2, learn1.cat3, learn1.epsilon2[,1], learn1.epsilon3[,1]),  yy1.weights),
    #                batch_size=batch0, epochs=epochs0, verbose=0, callbacks=CBs)
    #plot.loss("topright", fit[[2]], paste("network ",j0,"/",J0,", iteration ", t0, "/",T0, sep=""), ylim0=range(fit[[2]]), plot.yes=0, "", col0=c("blue","darkgreen", "orange"))
    load_model_weights_hdf5(model, path1)
    pred <- (model %>% predict(list(dat.design, dat.cat1, dat.cat2, dat.cat3, dat.epsilon2[,1], dat.epsilon3[,1]), batch_size=10^6))[,1]
    results2A[j0, t0] <- KL.divergence(dat$True, pred)
    if (t0==1){predE <- pred/T0
        }else{
          predE <- predE + pred/T0
          }
       }
    ensemble[j0] <- KL.divergence(dat$True, predE)
    }

###
cbind(round(rowMeans(results2A),4), round(ensemble,4))

